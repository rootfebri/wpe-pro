# Hooks

This contains two binaries `AStyleHelper.exe` and `AStyle.dll` to format any code before you commit.

If you are unsure about the integrity of the files, don't hesitate to contact me (mrexodia). The source code is available [here](https://github.com/mrexodia/AStyleHelper). The version of `AStyle.dll` is compiled from `AStyle_2.06_windows.zip` which came from [Sourceforge](https://sourceforge.net/projects/astyle/files/astyle/astyle%202.06/AStyle_2.06_windows.zip/download).