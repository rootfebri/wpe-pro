//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Strings.rc
//
#define IDS_SETUP                       101
#define IDS_ERROR                       105
#define IDS_ERRORGETTINGMODULEPATH      106
#define IDS_QUESTION                    107
#define IDS_ASKSHELLEXT                 108
#define IDS_ASKDESKTOPSHORTCUT          109
#define IDS_DONE                        110
#define IDS_NEWCFGWRITTEN               111
#define IDS_INVDPATH32                  112
#define IDS_INVDPATH64                  113
#define IDS_INVDPE                      114
#define IDS_FILEERR                     115
#define IDS_SHORTCUTDESC                116
#define IDS_ASKADMIN                    117
#define IDS_REGCREATEKEYFAIL            118
#define IDS_REGSETVALUEEXFAIL           119
#define IDS_REGOPENKEYFAIL              120
#define IDS_BRIDGEINITERR               121
#define IDS_SHELLEXTDBG                 122
#define IDS_ASKICON                     123
#define IDS_BRIDGESTARTERR              126

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
